// Env variable configuration.
require('dotenv').config();

//Import Express
const express = require('express');

// Set up the app as an express application
const app = express()
const path = require('path')

// Get mongoose access.
// Connect to the mongo DB using MONGO_URL env variable
const mongoose = require("mongoose")

mongoose.connect(process.env.MONGO_URL || 'mongodb://127.0.0.1', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    dbName: 'ClinicianPatients'
})

// Error handling
const db = mongoose.connection.on('error', err => {
    console.error(err);
    process.exit(1)
})

// Log to console once db is open
db.once('open', async () => {
    console.log(`Mongo connection started on ${db.host}:${db.port}`)
})

app.use(express.urlencoded());
app.use(express.json());

// Route Link
const registryRouter = require('./routes/patientRegistrationRouter')
app.use('/data-management', registryRouter)

// Handlebars
app.use(express.static(__dirname + '/public'));
const exphbs = require('express-handlebars');
const { addAbortSignal } = require('stream');
app.engine('hbs', exphbs.engine( {
    defaultLayout: 'main',
    extname: 'hbs'
}))

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

// Getting pages.
app.get('/', (req, res) => {
    res.render('index.hbs', {activeTab: {home: true}})
});

app.get('/about_diabetes', (req, res) => {
    res.render('about_diabetes.hbs', {activeTab: {about: true}})
})

app.get('/external_links', (req, res) => {
    res.render('external_links.hbs', {activeTab: {links: true}})
})

app.all('/clinician_view', (req, res) => {
    res.render('clinician_view.hbs')
})

app.post('/post-data', (req, res) => {
    db.collection('Patients').insertOne({ 
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        date_of_birth: new Date(req.body.date_of_birth),
        weight: parseInt(req.body.weight),
        record_glucose: !!req.body.record_glucose,
        record_weight: !!req.body.record_weight,
        record_insulin: !!req.body.record_insulin,
        record_exercise: !!req.body.record_exercise,
    });
    res.redirect('/clinician_view');
})


app.listen(3000, () => {
    console.log(`Listening to requests on http://localhost:${3000}`);
});