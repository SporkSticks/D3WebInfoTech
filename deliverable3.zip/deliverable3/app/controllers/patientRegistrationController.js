// Import registration model.
const Patient = require('../models/patientRegistrationModel')

// Request to get all data instances
const getaAllRegistrationData = async(req, res, next) => {
    try {
        const Patients = await Patient.find().lean()
        return res.render('allData', {data: Patients})
    } catch (err) {
        return next(err)
    }
}

const getDataById = async(req, res, next) => {
    try {
        const patient = await Author.findByID(req.params.patient_id).lean()
        if (!patient) {
            // No patient was found in the database.
            return res.send([])
        }
        // Patient was found
        return res.render('oneData', {oneItem: patient})
    } catch (err) {
        return next(err)
    }
}

// Export the object
module.exports = {
    getaAllRegistrationData,
    getDataById
}