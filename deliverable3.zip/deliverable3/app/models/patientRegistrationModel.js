const mongoose = require('mongoose')

const schema = new mongoose.Schema({
    first_name: {type: String, required: true},
    last_name: {type: String, required: true},
    weight: {type: Number, required: true},
    date_of_birth: {type: Date, required: true},
    record_glucose: Boolean,
    record_weight: Boolean,
    record_insulin: Boolean,
    record_exercise: Boolean
})

module.exports = mongoose.model('Patients', schema)