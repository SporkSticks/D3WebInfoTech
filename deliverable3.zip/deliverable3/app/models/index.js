// Load environment variables
if(process.env.NODE_ENV !== 'production') {
    require('dotenv').config()
}

require('./patientRegistrationModel')