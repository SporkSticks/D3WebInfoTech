MongoDB Credentials / Info
- Username: Spork
- Password: 4pUChd8kEywnSnjz
- Connection Link: MONGO_URL="mongodb+srv://Spork:4pUChd8kEywnSnjz@diabetesathomeproject.4odl1.mongodb.net/DiabetesAtHomeProject?retryWrites=true&w=majority"

Notes:
- The login page was not part of the assigned work so it does not have any proper authentication and will directly take a visitor
  to the clinician page when both fields are not left blank.
- The about diabetes / external links pages are both implemented as required
- The clinician page has a simplified UI as this was not part of the required work as the focus is more so on database functionality
  and whether the clinician is able to successfully interact with and insert novel patient data.
- There are 10 "existing" patients, each with their own assigned personal details. The clinician cannot edit data once it is put in.
- To receive data, the clinician can make a request to the database using the patient's ID number and the data will be printed onto the
  UI (this is for ease in testing).

  The design / colour scheme of the project was coordinated by me, and as such I have reused
  the designs of the webpages as I made them in the AdobeXD prototypes. UI icons are material design.
