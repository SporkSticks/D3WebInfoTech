const express = require('express')

// Create the router object.
const registrationRouter = express.Router()

// Import controller functions.
const registrationController = require('../controllers/patientRegistrationController')

// Add a route to handle GET requests for the registration data.
registrationRouter.get('/', registrationController.getaAllRegistrationData)

// Export router.
module.exports = registrationRouter